import { useRouter } from 'next/router';

function SomethingPage() {
    const router = useRouter();
    const newsId = router.query.newsId;
    //send a request to the backend API
    //to fetch news item with newsId

    return <h1>The Datails Page.</h1>
}


export default SomethingPage;