import Link from 'next/link';

import { Fragment } from 'react';
function NewsPage() {
    return(
        <Fragment>
            <h1>The News Page.</h1>
            <ul>
                <li>
                    <Link href='/news/next-js-is-a-great-framework'>NestJs is a greate Framework.</Link>
                </li>
                <li>Something do!!!!</li>
            </ul>
        </Fragment>
    ); 
}


export default NewsPage;